import { handlers } from "@/auth"

export const { GET, POST } = handlers // Referring to the auth.ts we just created

