"use client"

import React from 'react'

export default function Button({btnName}) {
  return (
    <button>{btnName}</button>
  )
}
