import React from 'react'
import { BounceLoader } from 'react-spinners'

export default function page() {
  return (
    <BounceLoader color="purple" />
  )
}
