import React from 'react'

export default function NotFound() {
  return (
    <div>
        <p className="text-center text-[red] height-[100vh]
         text-2xl">Sorry,, not found the page..!</p>
    </div>
  )
}
