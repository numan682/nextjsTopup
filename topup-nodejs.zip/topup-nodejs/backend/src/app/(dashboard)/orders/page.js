import React from "react";
import Orders from "../../components/Dashboard/Orders";

export default function page() {
  return (
    <>
      <Orders />
    </>
  );
}
