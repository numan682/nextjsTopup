import React from "react";

import AirBundlePack from "../../../components/Dashboard/AirBundlePack";

export default function page() {
  return (
    <>
      <AirBundlePack />
    </>
  );
}
