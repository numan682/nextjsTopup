import React from "react";
import AirDataPack from "../../../components/Dashboard/AirDataPack";

export default function page() {
  return (
    <>
      <AirDataPack />
    </>
  );
}
