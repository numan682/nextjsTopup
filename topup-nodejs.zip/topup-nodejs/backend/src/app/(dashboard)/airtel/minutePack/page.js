import React from "react";
import AirMinutePack from "../../../components/Dashboard/AirMinutePack";

export default function page() {
  return (
    <>
      <AirMinutePack />
    </>
  );
}
