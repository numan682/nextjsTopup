import React from "react";
import TeleMinutePack from "../../../components/Dashboard/TaleDataPack";

export default function page() {
  return (
    <>
      <TeleMinutePack />
    </>
  );
}
