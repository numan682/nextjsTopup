import React from "react";
import TaleDataPack from "../../../components/Dashboard/TaleDataPack";

export default function page() {
  return (
    <>
      <TaleDataPack />
    </>
  );
}
