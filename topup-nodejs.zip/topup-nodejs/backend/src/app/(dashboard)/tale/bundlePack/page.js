import React from "react";

import TaleBundlePack from "../../../components/Dashboard/TaleBundlePack";

export default function page() {
  return (
    <>
      <TaleBundlePack />
    </>
  );
}
