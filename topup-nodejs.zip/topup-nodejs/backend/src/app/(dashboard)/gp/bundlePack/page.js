import React from "react";
import GpBundlePack from "../../../components/Dashboard/GpBundlePack";

export default function page() {
  return (
    <>
      <GpBundlePack />
    </>
  );
}
