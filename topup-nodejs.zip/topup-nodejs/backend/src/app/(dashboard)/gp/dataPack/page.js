import React from "react";
import GpDataPack from "../../../components/Dashboard/GpDataPack";

export default function page() {
  return (
    <>
      <GpDataPack />
    </>
  );
}
