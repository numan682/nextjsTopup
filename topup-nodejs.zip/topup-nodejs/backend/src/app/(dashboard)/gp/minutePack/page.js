import React from "react";
import GpMinutePack from "../../../components/Dashboard/GpMinutePack";

export default function page() {
  return (
    <>
      <GpMinutePack />
    </>
  );
}
