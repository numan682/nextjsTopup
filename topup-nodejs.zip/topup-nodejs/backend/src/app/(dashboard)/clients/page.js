import React from "react";
import Clients from "../../components/Dashboard/Clients";
function page() {
  return (
    <>
      <Clients />
    </>
  );
}

export default page;
