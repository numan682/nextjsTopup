import React from "react";

import RobiBundlePack from "../../../components/Dashboard/robi/RobiBundlePack.jsx";

export default function page() {
  return (
    <>
      <RobiBundlePack />
    </>
  );
}
