import React from "react";
import RobiMinutePack from "../../../components/Dashboard/robi/RobiMinutePack";

export default function page() {
  return (
    <>
      <RobiMinutePack />
    </>
  );
}
