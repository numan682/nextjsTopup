import React from "react";
import RobiDataPack from "../../../components/Dashboard/robi/RobiDataPack";

export default function page() {
  return (
    <>
      <RobiDataPack />
    </>
  );
}
