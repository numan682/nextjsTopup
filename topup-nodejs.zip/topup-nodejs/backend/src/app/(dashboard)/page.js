import React from "react";
import DashboardIndex from "../components/Dashboard/DashboardIndex";

export default async function page() {
  return (
    <div>
      <DashboardIndex />
    </div>
  );
}
