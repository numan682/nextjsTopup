import React from "react";
import BLDataPack from "../../../components/Dashboard/BLDataPack";

export default function page() {
  return (
    <>
      <BLDataPack />
    </>
  );
}
