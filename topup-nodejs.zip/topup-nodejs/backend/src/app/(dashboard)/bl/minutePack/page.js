import React from "react";
import BLMinutePack from "../../../components/Dashboard/BLMinutePack";

export default function page() {
  return (
    <>
      <BLMinutePack />
    </>
  );
}
