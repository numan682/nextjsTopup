import React from "react";
import BLBundlePack from "../../../components/Dashboard/BLBundlePack";

export default function page() {
  return (
    <>
      <BLBundlePack />
    </>
  );
}
