-- AlterTable
ALTER TABLE "User" ADD COLUMN     "token" TEXT;
